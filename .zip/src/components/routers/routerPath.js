const paths = {
    home : "/",
    login : "/login",
    signup : "/signup",
    postRequirementNow : "/postRequirementNow",
}

module.exports = paths